package pendataan_pengangguran;

import javax.swing.JTable;

public interface Pendataan_Interface {

    public void read(JTable table);

    public void create(Pendataan p);

}
